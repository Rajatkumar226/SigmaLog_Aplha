/**
 * useDailyLogs Hook
 * ==================
 * React hook for managing daily habit logs with data integrity
 *
 * USAGE:
 * const { todayCompleted, toggleHabit, dailyScore, streak, loading } = useDailyLogs();
 */

import { useState, useEffect, useCallback } from 'react';
import * as logService from '../services/logService';
import * as milestoneService from '../services/milestoneService';
import { toast } from 'sonner';

export interface UseDailyLogsResult {
  todayCompleted: string[]; // Array of completed habit IDs
  dailyScore: logService.DailyScore | null;
  streak: number;
  loading: boolean;
  error: string | null;
  toggleHabit: (habitId: string) => Promise<boolean>;
  refetch: () => Promise<void>;
}

export function useDailyLogs(): UseDailyLogsResult {
  const [todayCompleted, setTodayCompleted] = useState<string[]>([]);
  const [dailyScore, setDailyScore] = useState<logService.DailyScore | null>(null);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchTodayData = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const today = new Date().toISOString().split('T')[0];

      // Fetch today's completed habits
      const completedResponse = await logService.getTodayCompletedHabits();
      if (completedResponse.success && completedResponse.data) {
        setTodayCompleted(completedResponse.data);
      }

      // Fetch today's score
      const scoreResponse = await logService.getDailyScore(today);
      if (scoreResponse.success && scoreResponse.data) {
        setDailyScore(scoreResponse.data);
      }

      // Calculate streak
      const streakResponse = await logService.calculateStreak();
      if (streakResponse.success && typeof streakResponse.data === 'number') {
        setStreak(streakResponse.data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTodayData();
  }, [fetchTodayData]);

  const toggleHabit = async (habitId: string): Promise<boolean> => {
    const isCompleted = todayCompleted.includes(habitId);

    try {
      if (isCompleted) {
        // Remove log
        const response = await logService.removeLog(habitId);

        if (response.success) {
          setTodayCompleted(prev => prev.filter(id => id !== habitId));

          // Refetch score and streak
          await fetchTodayData();

          return true;
        } else {
          toast.error(response.error || 'Failed to remove log');
          return false;
        }
      } else {
        // Add log
        const response = await logService.logHabit(habitId);

        if (response.success) {
          setTodayCompleted(prev => [...prev, habitId]);

          // Refetch score and streak
          await fetchTodayData();

          // Check for milestones
          const streakResponse = await logService.calculateStreak();
          if (streakResponse.success && typeof streakResponse.data === 'number') {
            const newStreak = streakResponse.data;
            const milestoneResponse = await milestoneService.checkAndCreateMilestone(newStreak);

            if (
              milestoneResponse.success &&
              milestoneResponse.data?.milestoneCreated &&
              milestoneResponse.data.milestoneType
            ) {
              const info = milestoneService.getMilestoneInfo(milestoneResponse.data.milestoneType);
              toast.success(`🎉 Milestone Unlocked: ${info.title}!`, {
                description: info.description,
                duration: 5000,
              });
            }
          }

          return true;
        } else {
          toast.error(response.error || 'Failed to log habit');
          return false;
        }
      }
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Failed to toggle habit';
      toast.error(errorMsg);
      return false;
    }
  };

  const refetch = async () => {
    await fetchTodayData();
  };

  return {
    todayCompleted,
    dailyScore,
    streak,
    loading,
    error,
    toggleHabit,
    refetch,
  };
}
