import { useState, useEffect } from 'react';
import { LandingScreen } from './components/LandingScreen';
import { HabitSetupScreen } from './components/HabitSetupScreen';
import { MainDashboard } from './components/MainDashboard';
import { ProgressScreen } from './components/ProgressScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { AuthScreen } from './components/AuthScreen';
import { MilestoneModal } from './components/MilestoneModal';

export interface Habit {
  id: string;
  name: string;
  category: 'Body' | 'Mind' | 'Career' | 'Discipline';
  points: 1 | 2 | 3;
}

export interface DailyLog {
  date: string;
  completedHabits: string[];
  score: number;
  maxScore: number;
}

type Screen = 'landing' | 'setup' | 'dashboard' | 'progress' | 'settings';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [habits, setHabits] = useState<Habit[]>([]);
  const [dailyLogs, setDailyLogs] = useState<DailyLog[]>([]);
  const [todayCompleted, setTodayCompleted] = useState<string[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showMilestone, setShowMilestone] = useState(false);

  // Check authentication on mount
  useEffect(() => {
    const authStatus = localStorage.getItem('sigmalog_auth');
    setIsAuthenticated(authStatus === 'true');
  }, []);

  // Load data from localStorage on mount
  useEffect(() => {
    if (!isAuthenticated) return;
    
    const savedHabits = localStorage.getItem('sigmalog_habits');
    const savedLogs = localStorage.getItem('sigmalog_logs');
    const savedScreen = localStorage.getItem('sigmalog_screen');

    if (savedHabits) {
      setHabits(JSON.parse(savedHabits));
    }
    if (savedLogs) {
      setDailyLogs(JSON.parse(savedLogs));
    }
    if (savedScreen && savedHabits) {
      setCurrentScreen(savedScreen as Screen);
    }

    // Load today's completed habits
    const today = new Date().toISOString().split('T')[0];
    if (savedLogs) {
      const logs = JSON.parse(savedLogs) as DailyLog[];
      const todayLog = logs.find(log => log.date === today);
      if (todayLog) {
        setTodayCompleted(todayLog.completedHabits);
      }
    }
  }, [isAuthenticated]);

  // Save habits to localStorage
  useEffect(() => {
    if (habits.length > 0) {
      localStorage.setItem('sigmalog_habits', JSON.stringify(habits));
    }
  }, [habits]);

  // Save logs to localStorage
  useEffect(() => {
    if (dailyLogs.length > 0) {
      localStorage.setItem('sigmalog_logs', JSON.stringify(dailyLogs));
    }
  }, [dailyLogs]);

  // Save current screen
  useEffect(() => {
    localStorage.setItem('sigmalog_screen', currentScreen);
  }, [currentScreen]);

  const startApp = () => {
    if (habits.length > 0) {
      setCurrentScreen('dashboard');
    } else {
      setCurrentScreen('setup');
    }
  };

  const lockHabits = (newHabits: Habit[]) => {
    setHabits(newHabits);
    setCurrentScreen('dashboard');
  };

  const toggleHabit = (habitId: string) => {
    const today = new Date().toISOString().split('T')[0];
    let newCompleted: string[];

    if (todayCompleted.includes(habitId)) {
      newCompleted = todayCompleted.filter(id => id !== habitId);
    } else {
      newCompleted = [...todayCompleted, habitId];
    }

    setTodayCompleted(newCompleted);

    // Update or create today's log
    const score = habits
      .filter(h => newCompleted.includes(h.id))
      .reduce((sum, h) => sum + h.points, 0);
    const maxScore = habits.reduce((sum, h) => sum + h.points, 0);

    const existingLogIndex = dailyLogs.findIndex(log => log.date === today);
    let newLogs: DailyLog[];

    if (existingLogIndex >= 0) {
      newLogs = [...dailyLogs];
      newLogs[existingLogIndex] = { date: today, completedHabits: newCompleted, score, maxScore };
    } else {
      newLogs = [...dailyLogs, { date: today, completedHabits: newCompleted, score, maxScore }];
    }

    setDailyLogs(newLogs);
  };

  const updateHabits = (newHabits: Habit[]) => {
    setHabits(newHabits);
    // Reset today's completed if habits change
    const today = new Date().toISOString().split('T')[0];
    const validCompleted = todayCompleted.filter(id => 
      newHabits.some(h => h.id === id)
    );
    setTodayCompleted(validCompleted);
  };

  const resetData = () => {
    setHabits([]);
    setDailyLogs([]);
    setTodayCompleted([]);
    localStorage.removeItem('sigmalog_habits');
    localStorage.removeItem('sigmalog_logs');
    setCurrentScreen('setup');
  };

  const handleAuthenticate = () => {
    setIsAuthenticated(true);
  };

  const handleSignOut = () => {
    // Clear auth
    localStorage.removeItem('sigmalog_auth');
    localStorage.removeItem('sigmalog_user_email');
    setIsAuthenticated(false);
    setCurrentScreen('landing');
  };

  // Show auth screen if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#0a0e1a] text-white">
        <AuthScreen onAuthenticate={handleAuthenticate} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      {currentScreen === 'landing' && (
        <LandingScreen onStart={startApp} />
      )}
      {currentScreen === 'setup' && (
        <HabitSetupScreen onLockHabits={lockHabits} existingHabits={habits} />
      )}
      {currentScreen === 'dashboard' && (
        <MainDashboard
          habits={habits}
          todayCompleted={todayCompleted}
          onToggleHabit={toggleHabit}
          dailyLogs={dailyLogs}
          onNavigate={setCurrentScreen}
        />
      )}
      {currentScreen === 'progress' && (
        <ProgressScreen
          habits={habits}
          dailyLogs={dailyLogs}
          onNavigate={setCurrentScreen}
        />
      )}
      {currentScreen === 'settings' && (
        <SettingsScreen
          habits={habits}
          onUpdateHabits={updateHabits}
          onResetData={resetData}
          onNavigate={setCurrentScreen}
          onSignOut={handleSignOut}
        />
      )}

      {/* Milestone Modal - Auto-shows on milestone achievements */}
      {showMilestone && (
        <MilestoneModal
          dailyLogs={dailyLogs}
          onClose={() => setShowMilestone(false)}
        />
      )}

      {/* Alpha version footer */}
      <div className="fixed bottom-0 left-0 right-0 p-4 text-center pointer-events-none">
        <p className="text-xs text-gray-700">
          Alpha version — discipline in progress
        </p>
      </div>
    </div>
  );
}