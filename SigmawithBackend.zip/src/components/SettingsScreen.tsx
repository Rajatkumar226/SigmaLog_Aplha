import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowLeft, Plus, Trash2, AlertTriangle, Bell, MessageSquare, Shield, LogOut } from 'lucide-react';
import { DataIntegrityIndicator } from './DataIntegrityIndicator';
import type { Habit } from '../App';

interface SettingsScreenProps {
  habits: Habit[];
  onUpdateHabits: (habits: Habit[]) => void;
  onResetData: () => void;
  onNavigate: (screen: 'dashboard') => void;
  onSignOut?: () => void;
}

export function SettingsScreen({
  habits,
  onUpdateHabits,
  onResetData,
  onNavigate,
  onSignOut,
}: SettingsScreenProps) {
  const [localHabits, setLocalHabits] = useState<Habit[]>(habits);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(() => {
    return localStorage.getItem('sigmalog_notifications') === 'true';
  });
  const [reminderTime, setReminderTime] = useState(() => {
    return localStorage.getItem('sigmalog_reminder_time') || '20:00';
  });

  // Save notification settings
  const handleNotificationToggle = (enabled: boolean) => {
    setNotificationsEnabled(enabled);
    localStorage.setItem('sigmalog_notifications', enabled.toString());
  };

  const handleReminderTimeChange = (time: string) => {
    setReminderTime(time);
    localStorage.setItem('sigmalog_reminder_time', time);
  };

  const addHabit = () => {
    const newHabit: Habit = {
      id: `habit-${Date.now()}`,
      name: 'New Habit',
      category: 'Body',
      points: 1,
    };
    setLocalHabits([...localHabits, newHabit]);
  };

  const updateHabit = (id: string, updates: Partial<Habit>) => {
    setLocalHabits(localHabits.map(h => (h.id === id ? { ...h, ...updates } : h)));
  };

  const deleteHabit = (id: string) => {
    setLocalHabits(localHabits.filter(h => h.id !== id));
  };

  const saveChanges = () => {
    onUpdateHabits(localHabits);
    onNavigate('dashboard');
  };

  const handleReset = () => {
    onResetData();
    setShowResetConfirm(false);
  };

  return (
    <div className="min-h-screen px-6 py-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => onNavigate('dashboard')}
            className="p-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h2>Settings</h2>
        </div>

        {/* Habit Editor */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white/5 border border-white/10 rounded-lg p-6 mb-6"
        >
          <h3 className="mb-4">Edit Habits</h3>
          
          <div className="space-y-3 mb-4">
            <AnimatePresence mode="popLayout">
              {localHabits.map((habit) => (
                <motion.div
                  key={habit.id}
                  initial={{ opacity: 0, y: 20, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="bg-white/5 border border-white/10 rounded-lg p-4"
                >
                  <div className="flex items-center gap-4">
                    <input
                      type="text"
                      value={habit.name}
                      onChange={(e) => updateHabit(habit.id, { name: e.target.value })}
                      className="flex-1 bg-transparent border-none outline-none text-white"
                      placeholder="Habit name"
                    />

                    <select
                      value={habit.category}
                      onChange={(e) =>
                        updateHabit(habit.id, {
                          category: e.target.value as Habit['category'],
                        })
                      }
                      className="bg-white/5 border border-white/10 rounded px-3 py-1.5 text-sm outline-none focus:border-white/20"
                    >
                      <option value="Body">Body</option>
                      <option value="Mind">Mind</option>
                      <option value="Career">Career</option>
                      <option value="Discipline">Discipline</option>
                    </select>

                    <select
                      value={habit.points}
                      onChange={(e) =>
                        updateHabit(habit.id, { points: Number(e.target.value) as 1 | 2 | 3 })
                      }
                      className="bg-white/5 border border-white/10 rounded px-3 py-1.5 text-sm outline-none focus:border-white/20"
                    >
                      <option value={1}>1 pt</option>
                      <option value={2}>2 pts</option>
                      <option value={3}>3 pts</option>
                    </select>

                    <button
                      onClick={() => deleteHabit(habit.id)}
                      className="p-2 hover:bg-white/5 rounded transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          <div className="flex gap-3">
            <button
              onClick={addHabit}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Habit
            </button>

            <button
              onClick={saveChanges}
              className="flex-1 px-6 py-2.5 bg-white text-black hover:bg-white/90 rounded-lg transition-all cursor-pointer"
            >
              Save Changes
            </button>
          </div>
        </motion.div>

        {/* Notification Settings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="bg-white/5 border border-white/10 rounded-lg p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Bell className="w-5 h-5" />
            <h3>Notifications</h3>
          </div>
          
          {/* Enable Toggle */}
          <div className="flex items-center justify-between mb-4 pb-4 border-b border-white/10">
            <div>
              <p className="text-sm mb-1">Daily Reminders</p>
              <p className="text-xs text-gray-500">
                No logs today yet. The mirror is still empty.
              </p>
            </div>
            <button
              onClick={() => handleNotificationToggle(!notificationsEnabled)}
              className={`relative w-12 h-6 rounded-full transition-colors ${
                notificationsEnabled ? 'bg-green-500/30' : 'bg-white/10'
              }`}
            >
              <motion.div
                animate={{ x: notificationsEnabled ? 24 : 2 }}
                transition={{ duration: 0.2 }}
                className={`absolute top-1 w-4 h-4 rounded-full ${
                  notificationsEnabled ? 'bg-green-500' : 'bg-gray-400'
                }`}
              />
            </button>
          </div>

          {/* Time Selector */}
          {notificationsEnabled && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
            >
              <label className="block text-sm text-gray-400 mb-2">
                Reminder Time
              </label>
              <input
                type="time"
                value={reminderTime}
                onChange={(e) => handleReminderTimeChange(e.target.value)}
                className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg 
                  outline-none focus:border-white/30 transition-colors"
              />
            </motion.div>
          )}
        </motion.div>

        {/* Data Integrity & Feedback */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 border border-white/10 rounded-lg p-6 mb-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Shield className="w-5 h-5" />
            <h3>Data Integrity</h3>
          </div>
          
          <div className="space-y-4">
            <DataIntegrityIndicator variant="inline" />
            
            <div className="pt-4 border-t border-white/10">
              <a
                href="mailto:feedback@sigmalog.app?subject=Alpha Feedback"
                className="flex items-center gap-2 px-4 py-2.5 bg-white/5 hover:bg-white/10 
                  border border-white/10 rounded-lg transition-all"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Share feedback</span>
              </a>
            </div>
          </div>
        </motion.div>

        {/* Danger Zone */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-red-500/5 border border-red-500/20 rounded-lg p-6"
        >
          <h3 className="mb-2 text-red-400">Danger Zone</h3>
          <p className="text-sm text-gray-400 mb-4">
            This will permanently delete all your habits and logged data.
          </p>

          {!showResetConfirm ? (
            <button
              onClick={() => setShowResetConfirm(true)}
              className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 rounded-lg transition-all cursor-pointer"
            >
              Reset All Data
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-400" />
              <span className="flex-1 text-sm">Are you sure?</span>
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-all cursor-pointer"
              >
                Confirm Reset
              </button>
            </div>
          )}
        </motion.div>

        {/* Sign Out */}
        {onSignOut && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white/5 border border-white/10 rounded-lg p-6 mt-6"
          >
            <h3 className="mb-2 text-gray-400">Account</h3>
            <p className="text-sm text-gray-400 mb-4">
              Sign out of your account.
            </p>

            <button
              onClick={onSignOut}
              className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 rounded-lg transition-all cursor-pointer"
            >
              Sign Out
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}