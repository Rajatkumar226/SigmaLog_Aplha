import { motion, AnimatePresence } from 'motion/react';
import { X, Copy, Share2 } from 'lucide-react';
import { useRef, useState } from 'react';
import type { DailyLog } from '../App';

interface ShareModalProps {
  dailyLogs: DailyLog[];
  onClose: () => void;
}

const shareMessages = {
  daily: 'Today\'s discipline',
  weekly: '7 days of action',
  monthly: '30 days of proof',
  quarterly: '90 days of evidence',
  yearly: '365 days unbroken',
};

function calculateStreak(dailyLogs: DailyLog[]): number {
  let streak = 0;
  const sortedLogs = [...dailyLogs].sort((a, b) => b.date.localeCompare(a.date));
  
  for (let i = 0; i < sortedLogs.length; i++) {
    const log = sortedLogs[i];
    if (log.score === log.maxScore) {
      streak++;
    } else {
      break;
    }
  }
  
  return streak;
}

export function ShareModal({ dailyLogs, onClose }: ShareModalProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [shareType, setShareType] = useState<'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly'>('daily');

  const today = new Date().toISOString().split('T')[0];
  const todayLog = dailyLogs.find(log => log.date === today);
  const score = todayLog?.score || 0;
  const maxScore = todayLog?.maxScore || 0;
  const streak = calculateStreak(dailyLogs);
  const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;

  const handleDownload = async () => {
    // Since html2canvas is not available, we'll copy the stats to clipboard instead
    const text = `SigmaLog - ${shareMessages[shareType]}\n\n${percentage}% complete\n${score}/${maxScore} points\n${streak}-day streak\n\n${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`;
    
    try {
      await navigator.clipboard.writeText(text);
      // Could show a toast notification here if needed
    } catch (error) {
      console.error('Error copying to clipboard:', error);
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'SigmaLog Progress',
          text: `${shareMessages[shareType]}: ${percentage}% completion, ${streak}-day streak`,
          url: window.location.href,
        });
      } catch (error) {
        console.error('Error sharing:', error);
      }
    } else {
      const text = `${shareMessages[shareType]}: ${percentage}% completion, ${streak}-day streak`;
      navigator.clipboard.writeText(text);
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50"
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-lg"
        >
          <div className="bg-[#0f1421] border border-white/20 rounded-lg p-6 shadow-2xl">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <h3>Share Progress</h3>
              <button
                onClick={onClose}
                className="p-2 hover:bg-white/5 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Period Selector */}
            <div className="flex gap-2 mb-6 overflow-x-auto">
              {(['daily', 'weekly', 'monthly', 'quarterly', 'yearly'] as const).map((type) => (
                <button
                  key={type}
                  onClick={() => setShareType(type)}
                  className={`px-3 py-1.5 rounded-lg text-sm transition-all whitespace-nowrap ${
                    shareType === type
                      ? 'bg-white/10 border border-white/20'
                      : 'bg-white/5 border border-white/10 hover:bg-white/[0.07]'
                  }`}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </button>
              ))}
            </div>

            {/* Shareable Card */}
            <div
              ref={cardRef}
              className="bg-[#0a0e1a] border border-white/10 rounded-lg p-8 mb-6"
            >
              <div className="text-center">
                {/* Logo/Title */}
                <div className="mb-6">
                  <h2 className="text-2xl mb-2">SigmaLog</h2>
                  <p className="text-sm text-gray-400">{shareMessages[shareType]}</p>
                </div>

                {/* Score Display */}
                <div className="mb-6">
                  <div className="inline-flex flex-col items-center justify-center w-32 h-32 border-4 border-white/20 rounded-full mb-4">
                    <span className="text-4xl">{percentage}%</span>
                    <span className="text-xs text-gray-400">complete</span>
                  </div>
                  
                  <p className="text-lg text-gray-300">
                    {score} / {maxScore} points
                  </p>
                </div>

                {/* Streak */}
                <div className="py-4 border-t border-white/10">
                  <p className="text-sm text-gray-400 mb-1">Current Streak</p>
                  <p className="text-2xl">{streak} {streak === 1 ? 'day' : 'days'}</p>
                </div>

                {/* Identity Message */}
                <div className="mt-6 pt-6 border-t border-white/10">
                  <p className="text-sm text-gray-400 italic">
                    {percentage === 100 
                      ? 'Discipline logged. Identity proven.'
                      : percentage >= 75
                      ? 'Building consistency through action.'
                      : 'The journey continues.'}
                  </p>
                </div>

                {/* Date */}
                <p className="text-xs text-gray-600 mt-4">
                  {new Date().toLocaleDateString('en-US', { 
                    month: 'long', 
                    day: 'numeric', 
                    year: 'numeric' 
                  })}
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleDownload}
                className="px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 
                  rounded-lg transition-all flex items-center justify-center gap-2"
              >
                <Copy className="w-4 h-4" />
                <span>Copy</span>
              </button>
              <button
                onClick={handleShare}
                className="px-4 py-3 bg-white/10 hover:bg-white/[0.15] border border-white/20 
                  rounded-lg transition-all flex items-center justify-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            </div>

            <p className="text-xs text-center text-gray-500 mt-4">
              Optional. Share when it feels right, not for validation.
            </p>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}