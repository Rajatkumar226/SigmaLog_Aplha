import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, Smartphone, Monitor, Info } from 'lucide-react';
import type { Habit } from '../App';

interface HabitSetupScreenProps {
  onLockHabits: (habits: Habit[]) => void;
  existingHabits: Habit[];
}

const DEFAULT_HABITS: Omit<Habit, 'id'>[] = [
  { name: 'Exercise', category: 'Body', points: 2 },
  { name: 'Reading', category: 'Mind', points: 1 },
  { name: 'Work', category: 'Career', points: 3 },
  { name: 'Meditation', category: 'Mind', points: 1 },
];

export function HabitSetupScreen({ onLockHabits, existingHabits }: HabitSetupScreenProps) {
  const [habits, setHabits] = useState<Habit[]>(
    existingHabits.length > 0
      ? existingHabits
      : DEFAULT_HABITS.map((h, i) => ({ ...h, id: `habit-${i}` }))
  );
  const [showPwaInstructions, setShowPwaInstructions] = useState(false);

  const addHabit = () => {
    const newHabit: Habit = {
      id: `habit-${Date.now()}`,
      name: 'New Habit',
      category: 'Body',
      points: 1,
    };
    setHabits([...habits, newHabit]);
  };

  const updateHabit = (id: string, updates: Partial<Habit>) => {
    setHabits(habits.map(h => (h.id === id ? { ...h, ...updates } : h)));
  };

  const deleteHabit = (id: string) => {
    setHabits(habits.filter(h => h.id !== id));
  };

  const handleLock = () => {
    if (habits.length > 0) {
      onLockHabits(habits);
    }
  };

  return (
    <div className="min-h-screen px-6 py-12">
      <div className="max-w-3xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          Define Your Discipline
        </motion.h2>

        <div className="space-y-3 mb-8">
          <AnimatePresence mode="popLayout">
            {habits.map((habit, index) => (
              <motion.div
                key={habit.id}
                initial={{ opacity: 0, y: 20, height: 0 }}
                animate={{ opacity: 1, y: 0, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3, delay: index * 0.08 }}
                className="bg-white/5 border border-white/10 rounded-lg p-4 hover:bg-white/[0.07] transition-colors"
              >
                <div className="flex items-center gap-4">
                  <input
                    type="text"
                    value={habit.name}
                    onChange={(e) => updateHabit(habit.id, { name: e.target.value })}
                    className="flex-1 bg-transparent border-none outline-none text-white"
                    placeholder="Habit name"
                  />

                  <select
                    value={habit.category}
                    onChange={(e) =>
                      updateHabit(habit.id, {
                        category: e.target.value as Habit['category'],
                      })
                    }
                    className="bg-white/5 border border-white/10 rounded px-3 py-1.5 text-sm outline-none focus:border-white/20 cursor-pointer"
                  >
                    <option value="Body">Body</option>
                    <option value="Mind">Mind</option>
                    <option value="Career">Career</option>
                    <option value="Discipline">Discipline</option>
                  </select>

                  <select
                    value={habit.points}
                    onChange={(e) =>
                      updateHabit(habit.id, { points: Number(e.target.value) as 1 | 2 | 3 })
                    }
                    className="bg-white/5 border border-white/10 rounded px-3 py-1.5 text-sm outline-none focus:border-white/20 cursor-pointer"
                  >
                    <option value={1}>1 pt</option>
                    <option value={2}>2 pts</option>
                    <option value={3}>3 pts</option>
                  </select>

                  <button
                    onClick={() => deleteHabit(habit.id)}
                    className="p-2 hover:bg-white/5 rounded transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4 text-gray-400" />
                  </button>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* PWA Install Prompt */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6 bg-white/5 border border-white/10 rounded-lg p-4"
        >
          <label className="flex items-start gap-3 cursor-pointer group">
            <input
              type="checkbox"
              checked={showPwaInstructions}
              onChange={(e) => setShowPwaInstructions(e.target.checked)}
              className="mt-0.5 w-5 h-5 rounded border-white/20 bg-white/5 
                checked:bg-white checked:border-white cursor-pointer
                focus:ring-2 focus:ring-white/20 focus:ring-offset-0"
            />
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Smartphone className="w-4 h-4 text-blue-400" />
                <Monitor className="w-4 h-4 text-purple-400" />
                <span className="text-sm font-medium group-hover:text-white transition-colors">
                  Add SigmaLog to Home Screen
                </span>
              </div>
              <p className="text-xs text-gray-500">
                Install as app for quick access and offline tracking
              </p>
            </div>
          </label>

          <AnimatePresence>
            {showPwaInstructions && (
              <motion.div
                initial={{ opacity: 0, height: 0, marginTop: 0 }}
                animate={{ opacity: 1, height: 'auto', marginTop: 16 }}
                exit={{ opacity: 0, height: 0, marginTop: 0 }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="space-y-3 pt-3 border-t border-white/10">
                  <div className="flex items-start gap-3">
                    <div className="bg-blue-500/10 p-2 rounded">
                      <Smartphone className="w-4 h-4 text-blue-400" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-medium mb-1">Mobile (iOS)</p>
                      <p className="text-xs text-gray-400">
                        Tap Share → Add to Home Screen
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-green-500/10 p-2 rounded">
                      <Smartphone className="w-4 h-4 text-green-400" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-medium mb-1">Mobile (Android)</p>
                      <p className="text-xs text-gray-400">
                        Menu (⋮) → Add to Home screen
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="bg-purple-500/10 p-2 rounded">
                      <Monitor className="w-4 h-4 text-purple-400" />
                    </div>
                    <div className="flex-1">
                      <p className="text-xs font-medium mb-1">Desktop</p>
                      <p className="text-xs text-gray-400">
                        Look for install icon in address bar or browser menu
                      </p>
                    </div>
                  </div>
                  <div className="bg-blue-500/5 border border-blue-500/20 rounded p-3 flex items-start gap-2">
                    <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
                    <p className="text-xs text-gray-400">
                      Installing as an app gives you faster access, offline support, and a native experience
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        <div className="flex gap-4">
          <button
            onClick={addHabit}
            className="flex items-center gap-2 px-4 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Habit
          </button>

          <button
            onClick={handleLock}
            disabled={habits.length === 0}
            className="flex-1 px-6 py-3 bg-white text-black hover:bg-white/90 rounded-lg transition-all disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
          >
            Lock My Rules
          </button>
        </div>
      </div>
    </div>
  );
}