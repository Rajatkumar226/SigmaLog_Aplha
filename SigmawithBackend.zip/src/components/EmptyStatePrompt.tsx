import { motion } from 'motion/react';
import { CheckCircle, TrendingUp, Calendar as CalendarIcon } from 'lucide-react';

export function EmptyStatePrompt() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white/5 border border-white/10 rounded-lg p-8 text-center max-w-2xl mx-auto"
    >
      <h3 className="mb-4">Welcome to SigmaLog</h3>
      <p className="text-gray-400 mb-8">
        Your discipline tracking system. Here's how it works:
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
        <div className="flex flex-col items-center text-center">
          <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-lg mb-3">
            <CheckCircle className="w-6 h-6 text-green-400" />
          </div>
          <h4 className="text-sm mb-2">1. Log Daily</h4>
          <p className="text-xs text-gray-400">
            Check off habits as you complete them throughout the day.
          </p>
        </div>

        <div className="flex flex-col items-center text-center">
          <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg mb-3">
            <TrendingUp className="w-6 h-6 text-blue-400" />
          </div>
          <h4 className="text-sm mb-2">2. Build Streaks</h4>
          <p className="text-xs text-gray-400">
            Complete all habits daily to build your discipline streak.
          </p>
        </div>

        <div className="flex flex-col items-center text-center">
          <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg mb-3">
            <CalendarIcon className="w-6 h-6 text-purple-400" />
          </div>
          <h4 className="text-sm mb-2">3. Track Progress</h4>
          <p className="text-xs text-gray-400">
            Watch your calendar fill up as you show up daily.
          </p>
        </div>
      </div>

      <div className="mt-8 p-4 bg-white/5 border border-white/10 rounded-lg">
        <p className="text-sm text-gray-400">
          <span className="text-white">Remember:</span> SigmaLog is not motivational. It's a mirror. 
          It shows who you are becoming through your daily choices.
        </p>
      </div>
    </motion.div>
  );
}
